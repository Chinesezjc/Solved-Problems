//This Code was made by Chinese_zjc_.
#include <iostream>
#include <fstream>
#include <iomanip>
#include <algorithm>
#include <vector>
#include <bitset>
#include <cmath>
#include <queue>
#include <stack>
#include <list>
#include <string>
#include <cstring>
#include <cstdio>
#include <cstdlib>
#include <cctype>
#include <map>
#include <set>
#include <ctime>
#include <random>
#include <chrono>
// #define debug
#define int long long
#define double long double
const double PI = acos(-1);
const double eps = 0.0000000001;
const int INF = 0x3fffffffffffffff;
unsigned long long seed = std::chrono::system_clock::now().time_since_epoch().count() / 1000000;
std::mt19937_64 Rand(seed);
std::string name = "10";
int n, m, k, x[300005], y[300005], p[10], lst;
struct way
{
    std::deque<int> no;
    int in[100005], out[100005];
    bool findconnect(int beg, int end)
    {
        return beg == end ? true : (out[beg] ? findconnect(y[out[beg]], end) : false);
    }
    void rep(int A, int B)
    {
        out[x[A]] = 0;
        in[y[A]] = 0;
        std::swap(A, no[B]);
        out[x[A]] = A;
        in[y[A]] = A;
    }
    void ins(int P)
    {
        int V = no[P];
        no.erase(no.begin() + P);
        out[x[V]] = V;
        in[y[V]] = V;
    }
} ans;
void read()
{
    std::ifstream in("hamil" + name + ".in"), out("hamil" + name + ".txt");
    in >> n >> m;
    for (int i = 0; i != 10; ++i)
        in >> p[i];
    for (int i = 1; i <= m; ++i)
        in >> x[i] >> y[i];
    in.close();
    if (out.fail())
    {
        std::ofstream tmp("hamil" + name + ".txt");
        tmp << m << std::endl;
        for (int i = 1; i <= m; ++i)
            tmp << i << " \n"[i == m];
        tmp.close();
        out.open("hamil" + name + ".txt");
    }
    out >> k;
    for (int i = 0; i != k; ++i)
    {
        static int t;
        out >> t;
        ans.no.push_back(t);
    }
    out.close();
    std::sort(ans.no.begin(), ans.no.end());
    for (int i = 1, j = 0; i <= m; ++i)
    {
        while (j != (int)ans.no.size() && ans.no[j] < i)
            ++j;
        if (j == (int)ans.no.size() || ans.no[j] != i)
            ans.out[x[i]] = i, ans.in[y[i]] = i;
    }
}
void print()
{
    std::ofstream out("hamil" + name + ".txt");
    out << ans.no.size() << std::endl;
    for (auto i : ans.no)
        out << ' ' << i;
    out << std::endl;
}
void output()
{
    std::ofstream out("hamil" + name + ".out");
    out << n << std::endl;
    for (int i = 1; i <= n; ++i)
        if (!ans.in[i])
            for (int now = i; now; now = y[ans.out[now]])
                out << now << ' ';
    out << std::endl;
    out.close();
}
signed main()
{
    std::ios::sync_with_stdio(false);
    read();
    print();
    while ((int)ans.no.size() != m - (n - 1))
    {
        int pos = Rand() % ans.no.size(), now = ans.no[pos];
        if ((ans.out[x[now]] && ans.in[y[now]]) || ans.findconnect(y[now], x[now]))
            continue;
        if ((ans.out[x[now]] || ans.in[y[now]]))
            Rand() & 1 ? ans.rep(ans.out[x[now]] + ans.in[y[now]], pos) : void(0);
        else
        {
            ans.ins(pos);
            if (clock() - lst > 1000)
                lst = clock(), print();
        }
        // for (int i = 1; i <= n; ++i)
        //     std::cout << ans.in[i] << " \n"[i == n];
        // for (int i = 1; i <= n; ++i)
        //     std::cout << ans.out[i] << " \n"[i == n];
    }
    output();
    return 0;
}